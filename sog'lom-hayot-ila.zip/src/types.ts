
export type ContentType = 'text' | 'link' | 'upload' | 'telegram';
export type Page = 'home' | 'services' | 'gallery' | 'about' | 'contact' | 'faq';

export interface ContentItem {
  id: string;
  title: string;
  description: string;
  type: ContentType;
  value: string; // URL, text content, or file path
  category: 'services' | 'news' | 'about';
  createdAt: number;
  telegramWidgetType?: 'post' | 'channel' | 'discussion';
}

export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
}
