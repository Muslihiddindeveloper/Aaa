import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  HeartPulse, 
  Stethoscope, 
  Activity, 
  Phone, 
  Mail, 
  MapPin, 
  ChevronRight,
  Copy,
  ExternalLink,
  Thermometer,
  Microscope,
  Baby,
  Wind,
  Droplets,
  Bug,
  Send
} from 'lucide-react';
import { Toaster } from '@/components/ui/sonner';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import Navbar from './components/Navbar';
import TelegramWidget from './components/TelegramWidget';
import { Page } from './types';
import { Language, translations } from './translations';
import { useShortcuts } from './hooks/useShortcuts';
import 'react-phone-number-input/style.css';
import PhoneInput from 'react-phone-number-input';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [lang, setLang] = useState<Language>('uz');
  const [userIp, setUserIp] = useState<string>('Aniqlanmadi');
  const [deviceInfo, setDeviceInfo] = useState<string>('Noma\'lum');

  const t = translations[lang];

  useEffect(() => {
    // Default to light theme on first load if no preference
    const savedTheme = localStorage.getItem('theme');
    if (!savedTheme) {
      document.documentElement.setAttribute('data-theme', 'light');
    }

    fetch('https://api.ipify.org?format=json')
      .then(res => res.json())
      .then(data => setUserIp(data.ip))
      .catch(() => setUserIp('Noma\'lum'));

    const ua = navigator.userAgent;
    let device = "Noma'lum qurilma";
    if (ua.match(/Android/i)) device = "Android";
    else if (ua.match(/iPhone|iPad|iPod/i)) device = "iOS";
    else if (ua.match(/Windows/i)) device = "Windows";
    else if (ua.match(/Linux/i)) device = "Linux";
    else if (ua.match(/Mac/i)) device = "macOS";
    
    // Simple version detection
    const version = ua.match(/(?:Windows NT|Android|OS|Version|MSIE|Firefox|Chrome)\s?([\d._]+)/);
    if (version) device += ` (${version[1]})`;
    
    setDeviceInfo(device);
  }, []);

  useShortcuts(setCurrentPage);

  const handleContactSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const data = {
      name: formData.get('name') as string,
      phone: formData.get('phone') as string,
      email: formData.get('email') as string,
      message: formData.get('message') as string,
      ip: userIp,
      device: deviceInfo
    };

    // Validation: Name only letters
    const nameRegex = /^[A-Za-zА-Яа-яЁё\s']+$/u;
    if (!nameRegex.test(data.name)) {
      toast.error(t.contact.name_error || "Ismda faqat harflar bo'lishi kerak");
      return;
    }

    // Validation: Email must have @ if provided
    if (data.email && !data.email.includes('@')) {
      toast.error(t.contact.email_error || "Yaroqli email kiriting");
      return;
    }

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (res.ok) {
        toast.success(t.contact.success);
        (e.target as HTMLFormElement).reset();
        return;
      }
      
      // If server route exists but returned error, throw to catch and try fallback
      throw new Error('Server error');
    } catch (err) {
      console.log('Server API not available or failed, trying client-side fallback...');
      
      // Client-side fallback for static hosts (Netlify, etc)
      // Note: This uses the Telegram Bot API directly from the browser
      const token = '8612596191:AAHpgAZGR6etKMAtcOLDw6cF27OjprD-4Yo';
      const chatId = '5302627260';
      
      const text = `
🆕 *Yangi Xabar (Static)*
👤 *Ism:* ${data.name}
📞 *Tel:* ${data.phone || 'Noma\'lum'}
📧 *Email:* ${data.email || 'Noma\'lum'}
📝 *Xabar:* ${data.message}

🌐 *IP:* ${data.ip || 'Noma\'lum'}
📱 *Qurilma:* ${data.device || 'Noma\'lum'}
      `.trim();

      try {
        const tgRes = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: chatId,
            text: text,
            parse_mode: 'Markdown'
          })
        });

        if (tgRes.ok) {
          toast.success(t.contact.success);
          (e.target as HTMLFormElement).reset();
        } else {
          toast.error(t.contact.error);
        }
      } catch (tgErr) {
        toast.error(t.contact.error);
      }
    }
  };

  const copyAndDial = (text: string, type: 'tel' | 'mail') => {
    navigator.clipboard.writeText(text);
    toast.info("Nusxalandi: " + text);
    if (type === 'tel') {
      window.location.href = `tel:${text.replace(/\s+/g, '')}`;
    } else {
      window.location.href = `mailto:${text}`;
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'services': return <ServicesPage lang={lang} />;
      case 'about': return <AboutPage lang={lang} />;
      case 'contact': return <ContactPage lang={lang} onSubmit={handleContactSubmit} copyFn={copyAndDial} />;
      case 'faq': return <FAQPage lang={lang} />;
      default: return <HomePage lang={lang} setCurrentPage={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-sans transition-colors duration-300">
      <Navbar 
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        lang={lang}
        setLang={setLang}
      />
      <Toaster position="top-center" />
      
      <main className="pt-20">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.4, ease: "easeInOut" }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>

      <footer className="py-12 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 text-emerald-700 dark:text-emerald-400 mb-4">
            <HeartPulse className="h-6 w-6" />
            <span className="text-xl font-bold italic">Sog'lom Hayot Ila</span>
          </div>
          <p className="text-slate-500 dark:text-slate-400">© 2026 Sog'lom Hayot Ila. {translations[lang].nav.all_rights || (lang === 'uz' ? 'Barcha huquqlar himoyalangan.' : lang === 'ru' ? 'Все права защищены.' : 'All rights reserved.')}</p>
        </div>
      </footer>
    </div>
  );
}

// Sub-components for better organization

function HomePage({ lang, setCurrentPage }: { lang: Language, setCurrentPage: (p: Page) => void }) {
  const t = translations[lang];
  const tabs = t.hero_tabs || [];
  const carouselItems = t.carousel?.items || [];
  const [carouselIndex, setCarouselIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCarouselIndex((prev) => (prev + 1) % carouselItems.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [carouselItems.length]);
  
  const tabIcons = [
    <Stethoscope className="h-8 w-8" />,
    <HeartPulse className="h-8 w-8" />,
    <Microscope className="h-8 w-8" />,
    <Phone className="h-8 w-8" />
  ];

  return (
    <section className="relative py-12 lg:py-24 min-h-[85vh] flex flex-col items-center">
      <div className="absolute top-0 right-0 -z-10 w-1/3 h-full bg-emerald-50/30 dark:bg-emerald-950/10 rounded-l-[100px] hidden lg:block" />
      
      {/* Carousel */}
      <div className="w-full max-w-4xl px-4 mb-16 overflow-hidden relative h-24">
        <AnimatePresence mode="wait">
          <motion.div
            key={carouselIndex}
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            className="absolute inset-0 flex flex-col items-center justify-center text-center"
          >
            <span className="text-emerald-600 font-black uppercase tracking-widest text-xs mb-2">Special Service</span>
            <h2 className="text-2xl lg:text-3xl font-black text-slate-800 dark:text-white uppercase mb-1">
              {carouselItems[carouselIndex]?.title}
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium italic">
              {carouselItems[carouselIndex]?.text}
            </p>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="text-center mb-16 lg:mb-24">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl lg:text-7xl font-black text-slate-900 dark:text-white mb-6 uppercase italic tracking-tighter leading-none"
          >
            SOG'LOM <span className="text-emerald-600">HAYOT</span> ILA
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-lg lg:text-xl text-slate-600 dark:text-slate-400 max-w-2xl mx-auto font-medium"
          >
            {t.hero.subtitle}
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {tabs.map((tab, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 + 0.3 }}
              onClick={() => setCurrentPage(tab.page as Page)}
              whileHover={{ 
                y: -15,
                scale: 1.02,
                transition: { type: 'spring', stiffness: 400, damping: 10 }
              }}
              className="group cursor-pointer p-8 lg:p-10 rounded-[3rem] bg-white dark:bg-slate-800 border-2 border-emerald-50 dark:border-emerald-900 shadow-xl shadow-emerald-100/50 dark:shadow-none hover:shadow-2xl hover:shadow-emerald-200/50 transition-all relative overflow-hidden"
            >
              <div className="absolute -right-4 -top-4 w-24 h-24 bg-emerald-500/5 rounded-full group-hover:scale-150 transition-transform duration-1000" />
              
              <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-900/50 rounded-2xl flex items-center justify-center text-emerald-600 mb-8 group-hover:bg-emerald-600 group-hover:text-white transition-colors duration-500">
                {tabIcons[i]}
              </div>
              
              <h3 className="text-2xl font-black mb-3 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors uppercase tracking-tighter leading-tight">
                {tab.title}
              </h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-medium leading-relaxed italic">
                {tab.desc}
              </p>
              
              <div className="mt-8 flex items-center text-emerald-600 font-black text-xs uppercase tracking-[3px] opacity-0 group-hover:opacity-100 transition-all">
                <span>{translations[lang].hero.cta}</span>
                <ChevronRight className="ml-1 h-3 w-3" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ServicesPage({ lang }: { lang: Language }) {
  const t = translations[lang].services;
  const icons = [
    <Stethoscope />, 
    <Thermometer />, 
    <Droplets />, 
    <Activity />, 
    <Wind />, 
    <Droplets />, 
    <Microscope />, 
    <Baby />, 
    <Bug />
  ];

  const animations = [
    { rotate: [0, 10, -10, 0] },
    { y: [0, -4, 0] },
    { scale: [1, 1.1, 1] },
    { x: [0, 2, -2, 0] },
    { opacity: [1, 0.6, 1] },
    { scale: [1, 1.05, 1] },
    { rotate: [0, 360] },
    { scaleX: [1, 1.1, 1] },
    { scale: [1, 1.2, 1] }
  ];

  return (
    <section className="py-12 lg:py-20 px-4 max-w-7xl mx-auto">
      <h2 className="text-3xl lg:text-5xl font-black mb-12 text-center text-emerald-600 uppercase italic tracking-tighter">{t.title}</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6 lg:gap-8">
        {t.list.map((s, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            whileHover={{ 
              y: -12, 
              scale: 1.02,
              transition: { type: 'spring', stiffness: 300, damping: 15 }
            }}
            className="p-8 lg:p-10 rounded-[2.5rem] bg-white dark:bg-slate-800 border-2 border-emerald-50 dark:border-emerald-900 shadow-sm hover:shadow-2xl hover:shadow-emerald-200/50 dark:hover:shadow-emerald-900/30 transition-all relative group overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-1000" />
            
            <motion.div 
              animate={animations[i]}
              transition={{ 
                duration: 2, 
                repeat: Infinity, 
                ease: "easeInOut" 
              }}
              className="w-16 h-16 bg-emerald-100 dark:bg-emerald-900/50 rounded-2xl flex items-center justify-center text-emerald-600 mb-8 text-3xl"
            >
              {icons[i]}
            </motion.div>
            
            <h3 className="text-2xl font-black mb-4 group-hover:text-emerald-600 transition-colors tracking-tight">{s.title}</h3>
            <p className="text-slate-500 dark:text-slate-400 font-medium leading-relaxed italic">{s.desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

function FAQPage({ lang }: { lang: Language }) {
  const f = translations[lang].faq;
  const questions = [
    { q: f.q1, a: f.a1 },
    { q: f.q2, a: f.a2 },
    { q: f.q3, a: f.a3 },
    { q: f.q4, a: f.a4 },
    { q: f.q5, a: f.a5 },
    { q: f.q6, a: f.a6 },
  ];
  return (
    <section className="py-20 px-4 max-w-3xl mx-auto">
      <h2 className="text-4xl font-black mb-12 text-emerald-600 text-center uppercase tracking-tighter">{f.title}</h2>
      <div className="space-y-6">
        {questions.map((item, i) => (
          <div key={i} className="p-8 rounded-3xl bg-white dark:bg-slate-800 border-2 border-emerald-50 dark:border-emerald-900">
            <h3 className="text-xl font-bold mb-4 text-emerald-700 dark:text-emerald-400">? {item.q}</h3>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed font-medium">{item.a}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function AboutPage({ lang }: { lang: Language }) {
  const t = translations[lang].about_extra;
  return (
    <section className="py-12 lg:py-24 px-4 max-w-5xl mx-auto">
      <div className="flex flex-col items-center">
        <div className="w-full">
          <motion.h2 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-4xl lg:text-6xl font-black mb-12 text-emerald-600 text-center uppercase italic tracking-[10px]"
          >
            {t.title}
          </motion.h2>
          <div className="text-lg lg:text-xl leading-relaxed mb-12 font-medium text-center space-y-8">
             <p className="max-w-3xl mx-auto text-slate-600 dark:text-slate-300">
               {t.subtitle}
             </p>
             
             <motion.div 
              whileHover={{ scale: 1.02 }}
              className="p-8 lg:p-16 bg-emerald-600 text-white rounded-[3rem] lg:rounded-[5rem] shadow-3xl shadow-emerald-200 dark:shadow-none inline-block w-full cursor-default relative overflow-hidden group"
             >
                <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full group-hover:scale-110 transition-transform duration-700" />
                <p className="text-2xl lg:text-4xl font-black mb-10 uppercase tracking-tighter leading-none">
                  {t.only_target}
                </p>
                <div className="bg-white/10 backdrop-blur-xl rounded-[2rem] lg:rounded-[3rem] p-8 lg:p-12 text-left border border-white/20">
                  <ul className="space-y-6 font-black text-sm lg:text-lg">
                    {t.features.map((item, idx) => (
                      <motion.li 
                        key={idx}
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.2 }}
                        className="flex items-center space-x-4 group/item cursor-pointer"
                      >
                        <motion.div whileHover={{ scale: 1.3, rotate: 360 }} className="bg-white text-emerald-600 p-2 rounded-xl shadow-lg">
                          <HeartPulse className="h-5 w-5 shrink-0" />
                        </motion.div>
                        <span className="group-hover/item:text-emerald-100 transition-all">{item}</span>
                      </motion.li>
                    ))}
                  </ul>
                </div>
             </motion.div>
          </div>

          <div className="flex flex-col items-center space-y-6 mt-16">
             <motion.div 
              whileHover={{ y: -5 }}
              className="flex items-center space-x-4 p-8 bg-white dark:bg-slate-800 rounded-[2.5rem] w-full max-w-2xl border-4 border-dashed border-emerald-100 dark:border-emerald-900 shadow-sm"
             >
                <MapPin className="text-emerald-600 h-8 w-8 shrink-0" />
                <span className="text-base lg:text-lg font-black uppercase tracking-tight leading-tight">{translations[lang].contact.address_val}</span>
             </motion.div>
             
             <motion.a 
               whileHover={{ scale: 1.05, y: -5 }}
               whileTap={{ scale: 0.95 }}
               href="https://maps.app.goo.gl/WYPowNUkwyAS5Adg9" 
               target="_blank" 
               className="inline-flex items-center space-x-3 px-12 py-6 bg-slate-900 text-emerald-400 rounded-full font-black uppercase tracking-[5px] hover:bg-slate-800 transition-all shadow-2xl"
             >
               <ExternalLink className="h-6 w-6" />
               <span>{t.view_map}</span>
             </motion.a>
          </div>
        </div>
      </div>
    </section>
  );
}

function ContactPage({ lang, onSubmit, copyFn }: { lang: Language, onSubmit: (e: any) => void, copyFn: (t: string, type: 'tel' | 'mail') => void }) {
  const c = translations[lang].contact;
  const [phoneNumber, setPhoneNumber] = useState<string | undefined>();

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    // Explicitly set phone from state because PhoneInput might not put it in name attribute the same way or it might be easier this way
    if (phoneNumber) {
      formData.set('phone', phoneNumber);
    }
    // Create a proxy event or just call onSubmit with custom data
    // onSubmit is expecting the event usually, but handleContactSubmit uses formData
    // So we need to make sure the phone is in the formData
    onSubmit(e);
  };

  return (
    <section className="py-20 px-4 max-w-7xl mx-auto">
      <div className="bg-slate-900 rounded-[60px] p-8 lg:p-20 text-white relative overflow-hidden">
        <div className="grid lg:grid-cols-2 gap-16 items-start relative z-10">
          <div>
            <h2 className="text-5xl font-black mb-12 text-emerald-400">{c.title}</h2>
            <div className="space-y-8 text-lg font-medium">
               <div className="flex items-center space-x-4">
                 <MapPin className="text-emerald-500" />
                 <p>{c.address_val}</p>
               </div>
               <button 
                onClick={() => copyFn('+998 94 441 36 62', 'tel')}
                className="flex items-center space-x-4 hover:text-emerald-300 transition-colors group"
               >
                 <Phone className="text-emerald-500" />
                 <span>+998 94 441 36 62</span>
                 <Copy className="h-4 w-4 opacity-0 group-hover:opacity-100" />
               </button>
               <button 
                onClick={() => copyFn('soglomhayotila@gmail.com', 'mail')}
                className="flex items-center space-x-4 hover:text-emerald-300 transition-colors group"
               >
                 <Mail className="text-emerald-500" />
                 <span>soglomhayotila@gmail.com</span>
                 <Copy className="h-4 w-4 opacity-0 group-hover:opacity-100" />
               </button>
               <a 
                href="https://t.me/soglom_hayot_ila" 
                target="_blank"
                className="flex items-center space-x-4 text-sky-400 hover:text-sky-300 transition-colors"
               >
                 <Send />
                 <span>telegram/soglom_hayot_ila</span>
               </a>
            </div>
            <div className="mt-12 rounded-3xl overflow-hidden border-4 border-slate-800">
               <iframe 
                src="https://yandex.com/map-widget/v1/?ll=71.0675897%2C40.5032805&z=18&l=sat&pt=71.0675897%2C40.5032805%2Cpm2rdm" 
                className="w-full h-80 border-0"
                allowFullScreen={true} 
              />
            </div>
          </div>
          <div className="bg-white/5 backdrop-blur-xl p-8 lg:p-12 rounded-[40px] border border-white/10">
             <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-bold uppercase mb-2 text-slate-400">{c.form_name}</label>
                  <input name="name" required type="text" className="w-full bg-slate-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-emerald-500 text-white" />
                </div>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold uppercase mb-2 text-slate-400">{c.form_phone_optional || c.form_phone}</label>
                    <PhoneInput
                      placeholder={c.form_phone}
                      value={phoneNumber}
                      onChange={setPhoneNumber}
                      defaultCountry="UZ"
                      countries={['UZ', 'KZ', 'KG', 'TJ', 'TM', 'AF']}
                      addInternationalOption={false}
                      displayInitialValueAsLocalNumber
                      className="contact-phone-input"
                    />
                    <input type="hidden" name="phone" value={phoneNumber || ''} />
                  </div>
                  <div>
                    <label className="block text-sm font-bold uppercase mb-2 text-slate-400">{c.form_email_optional || c.form_email}</label>
                    <input name="email" type="email" className="w-full bg-slate-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-emerald-500 text-white" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold uppercase mb-2 text-slate-400">{c.form_msg}</label>
                  <textarea name="message" required rows={4} className="w-full bg-slate-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-emerald-500 text-white"></textarea>
                </div>
                <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 h-16 text-xl rounded-2xl font-black uppercase">
                  {c.send}
                </Button>
             </form>
          </div>
        </div>
      </div>
    </section>
  );
}

