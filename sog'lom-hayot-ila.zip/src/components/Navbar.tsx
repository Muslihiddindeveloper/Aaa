
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, HeartPulse, Moon, Sun, ChevronRight, Eye } from 'lucide-react';
import { Language, translations } from '@/src/translations';
import { Page } from '@/src/types';
import { useTheme } from 'next-themes';

interface NavbarProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  lang: Language;
  setLang: (lang: Language) => void;
}

export default function Navbar({ currentPage, setCurrentPage, lang, setLang }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const t = translations[lang].nav;

  const cycleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  const getThemeIcon = () => {
    return theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />;
  };

  const getThemeLabel = () => {
    return theme === 'dark' ? t.theme_light : t.theme_dark;
  };

  const navLinks: { name: string; page: Page }[] = [
    { name: t.services, page: 'services' },
    { name: t.about, page: 'about' },
    { name: t.faq, page: 'faq' },
    { name: t.contact, page: 'contact' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-emerald-100 dark:border-emerald-900 transition-all duration-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center">
            <button
              onClick={() => setCurrentPage('home')}
              className="group flex items-center space-x-2 text-emerald-700 dark:text-emerald-400 hover:text-emerald-800 transition-all duration-300"
            >
              <motion.div
                animate={{ scale: [1, 1.15, 1] }}
                transition={{ 
                  duration: 1.5, 
                  repeat: Infinity, 
                  ease: "easeInOut",
                  times: [0, 0.2, 0.4] // Creates a "dub-dub" pulse feel
                }}
              >
                <HeartPulse className="h-8 w-8 group-hover:drop-shadow-[0_0_10px_rgba(16,185,129,0.8)]" />
              </motion.div>
              <span className="text-xl font-black tracking-tighter uppercase italic group-hover:tracking-normal transition-all duration-500">
                Sog'lom Hayot Ila
              </span>
            </button>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <motion.button
                key={link.page}
                onClick={() => setCurrentPage(link.page)}
                whileHover={{ scale: 1.05 }}
                className={`text-sm font-black uppercase tracking-widest transition-all relative group ${
                  currentPage === link.page
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-gray-600 dark:text-gray-300 hover:text-emerald-600'
                }`}
              >
                {link.name}
                <motion.span 
                  className={`absolute -bottom-1 left-0 w-full h-0.5 bg-emerald-500 origin-left ${currentPage === link.page ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}
                  transition={{ duration: 0.3 }}
                />
              </motion.button>
            ))}

            <div className="flex items-center space-x-4 border-l pl-6 dark:border-slate-700">
              {/* Language Switcher */}
              <div className="flex space-x-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
                {(['uz', 'ru', 'en'] as Language[]).map((l) => (
                  <button
                    key={l}
                    onClick={() => setLang(l)}
                    className={`px-2 py-1 text-[10px] font-black rounded-md transition-all ${
                      lang === l
                        ? 'bg-emerald-600 text-white shadow-sm'
                        : 'text-gray-400 hover:text-emerald-600'
                    }`}
                  >
                    {l.toUpperCase()}
                  </button>
                ))}
              </div>

              {/* Theme Toggle */}
              <button
                onClick={cycleTheme}
                title={getThemeLabel()}
                className="p-2 text-gray-500 hover:text-emerald-600 dark:text-gray-400 bg-slate-50 dark:bg-slate-800 rounded-full transition-colors flex items-center space-x-2"
              >
                {getThemeIcon()}
                <span className="text-[10px] font-black uppercase">{getThemeLabel()}</span>
              </button>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center space-x-2">
            <button
              onClick={cycleTheme}
              className="p-2.5 text-gray-500 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center space-x-1"
            >
              {getThemeIcon()}
              <span className="text-[10px] font-black uppercase">{getThemeLabel()}</span>
            </button>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-emerald-600 bg-emerald-50 dark:bg-emerald-900/30 p-2.5 rounded-xl border border-emerald-100 dark:border-emerald-800"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="md:hidden bg-white dark:bg-slate-900 border-b border-emerald-100 dark:border-emerald-900 overflow-hidden shadow-2xl"
          >
            <div className="px-6 pt-4 pb-8 space-y-3">
              {navLinks.map((link, idx) => (
                <motion.button
                  key={link.page}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  onClick={() => {
                    setCurrentPage(link.page);
                    setIsOpen(false);
                  }}
                  className={`block w-full text-left px-5 py-4 rounded-2xl font-black uppercase tracking-tighter text-lg transition-all ${
                    currentPage === link.page
                      ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200 dark:shadow-none'
                      : 'text-gray-600 dark:text-gray-300 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 hover:text-emerald-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span>{link.name}</span>
                    <ChevronRight className="h-5 w-5 opacity-50" />
                  </div>
                </motion.button>
              ))}
              <div className="pt-6 mt-6 border-t dark:border-slate-800 flex items-center justify-between">
                <span className="text-xs font-black uppercase tracking-widest text-gray-400">Tilni tanlang:</span>
                <div className="flex space-x-2 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                  {(['uz', 'ru', 'en'] as Language[]).map((l) => (
                    <button
                      key={l}
                      onClick={() => setLang(l)}
                      className={`px-3 py-1.5 text-xs font-black rounded-lg transition-all ${
                        lang === l 
                          ? 'bg-emerald-600 text-white' 
                          : 'text-gray-500'
                      }`}
                    >
                      {l.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
