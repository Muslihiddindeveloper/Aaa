
import { useEffect, useRef } from 'react';

interface TelegramWidgetProps {
  url: string;
  type?: 'post' | 'channel' | 'discussion';
}

export default function TelegramWidget({ url, type = 'post' }: TelegramWidgetProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Clear existing content
    containerRef.current.innerHTML = '';

    const script = document.createElement('script');
    script.async = true;

    // Extract post ID or channel name from URL
    // Example: https://t.me/channel/123 -> channel/123
    const path = url.replace('https://t.me/', '');
    
    if (type === 'post') {
      script.src = 'https://telegram.org/js/telegram-widget.js?22';
      script.setAttribute('data-telegram-post', path);
      script.setAttribute('data-width', '100%');
    } else if (type === 'channel') {
      script.src = 'https://telegram.org/js/telegram-widget.js?22';
      script.setAttribute('data-telegram-discussion', path);
      script.setAttribute('data-width', '100%');
    } else {
      // Fallback or other types
      script.src = 'https://telegram.org/js/telegram-widget.js?22';
      script.setAttribute('data-telegram-post', path);
      script.setAttribute('data-width', '100%');
    }

    containerRef.current.appendChild(script);
  }, [url, type]);

  return (
    <div className="w-full overflow-hidden rounded-xl border border-emerald-100 bg-emerald-50/30 p-2">
      <div ref={containerRef} className="telegram-widget-container min-h-[200px] flex items-center justify-center">
        <span className="text-emerald-600 text-sm animate-pulse">Telegram widget yuklanmoqda...</span>
      </div>
    </div>
  );
}
