
export type Language = 'uz' | 'ru' | 'en';

export const translations = {
  uz: {
    nav: {
      home: 'Bosh sahifa',
      services: 'Xizmatlar',
      gallery: 'Galereya',
      about: 'Biz haqimizda',
      contact: 'Aloqa',
      faq: 'Savollar',
      theme_light: 'Kunduzgi',
      theme_dark: 'Tungi',
    },
    carousel: {
      items: [
        { title: 'Sifatli xizmat', text: 'Eng zamonaviy uskunalar bilan xizmat ko\'rsatamiz.' },
        { title: 'Tajribali tabiba', text: 'Ko\'p yillik tajribaga ega tabibamiz mavjud.' },
        { title: 'Tabiiy dorilar', text: 'Barcha mualojalarimizda 100% tabiiy dorilar ishlatiladi.' },
      ]
    },
    hero: {
      title: 'Sog\'lom hayot sari birgalikda qadam tashlaymiz',
      subtitle: 'Zamonaviy tibbiyot va xalq tabobati uyg\'unligida sizga eng yaxshi xizmatlarni taklif etamiz.',
      cta: 'Xizmatlarimiz',
    },
    hero_tabs: [
      { title: 'Xizmatlar', desc: 'Barcha tibbiy xizmatlarimiz va mualojalar', page: 'services' },
      { title: 'Biz haqimizda', desc: 'Markazimiz tarixi va qadriyatlarimiz', page: 'about' },
      { title: 'Savollar', desc: 'Ko\'p beriladigan savollarga javoblar', page: 'faq' },
      { title: 'Aloqa', desc: 'Manzilimiz va bog\'lanish yo\'llari', page: 'contact' },
    ],
    services: {
      title: 'Xizmatlarimiz',
      list: [
        { title: "Umumiy ko'rik", desc: "TANITA aparati yordamida boshdan oyoq ko'rik." },
        { title: "Immunitetni mustahkamlash", desc: "Tabiiy dorilar bilan imunitetni barqarorlashtirish." },
        { title: "Zuluk bilan davolash", desc: "Zuluklar yordamida qonni tozalash va davolash." },
        { title: "Ichki kasalliklar", desc: "Oshqozon-ichak kasalligi, kamqonlik, vitamin yetishmasligi va bepushlikni davolash." },
        { title: "Elektroforez", desc: "Zamonaviy fizioterapiya usullaridan foydalanish." },
        { title: "Parafin bilan davolash", desc: "Qizituvchi va davolovchi parafin muolajalari." },
        { title: "Hijoma", desc: "Xalq tabobati asosida qon oldirish (Hijama)." },
        { title: "Ayollar va bolalar masaji", desc: "Malakali tabiba tomonidan professional masaj." },
        { title: "Gijjalardan samaraliy davolash", desc: "Gijjalardan samarali va tabiiy davolash!" }
      ]
    },
    about_extra: {
      title: 'Biz haqimizda',
      subtitle: 'Sog\'lom hayot sari intilish - har bir insonning asosiy maqsadi. Bizning markazimiz sizga bu yo\'lda eng sifatli va tabiiy mualojalarni taqdim etadi.',
      only_target: 'Xizmatlar faqatgina AYOL VA BOLALAR uchun!',
      features: [
        'Ayollar va bolalarni hijoma va masaj qilamiz',
        'Tabibamiz: ayol kishi',
        'Dorilarimiz: 100% tabiiy'
      ],
      view_map: 'XARITADA KO\'RISH'
    },
    contact: {
      title: 'Biz bilan bog\'laning',
      address: 'Manzil',
      address_val: 'Farg\'ona viloyati, Uchko\'prik tumani, Katta qo\'shtepa qishlog\'i, Obod mahalla, 5-uy',
      phone: 'Telefon',
      email: 'Email',
      send: 'Xabarni yuborish',
      form_name: 'Ismingiz',
      form_phone: 'Telefon raqamingiz',
      form_email: 'Email',
      email_error: 'Yaroqli email kiriting (@ belgi bo\'lishi shart)',
      name_error: 'Ismda faqat harflar bo\'lishi kerak',
      form_phone_optional: 'Telefon raqamingiz (ixtiyoriy)',
      form_email_optional: 'Email manzilingiz (ixtiyoriy)',
      form_msg: 'Xabaringiz',
      success: 'Xabar muvaffaqiyatli yuborildi!',
      error: 'Xabar yuborishda xatolik yuz berdi.',
      requirement: 'Kamida telefon yoki email kiritilishi shart!',
    },
    faq: {
      title: 'Ko\'p uchraydigan savollar',
      q1: 'Ish vaqtingiz qachon?',
      a1: 'Markazimiz har kuni soat 08:00 dan 16:00 gacha xizmat ko\'rsatadi.',
      q2: 'Masaj xizmati kimlar uchun?',
      a2: 'Bizda faqatgina ayollar va bolalar uchun professional masaj xizmatlari mavjud.',
      q3: 'Hijoma qanday hollarda foydali?',
      a3: 'Hijoma qon aylanishini yaxshilash, bosh og\'rig\'i va umumiy xolatsizlikda samarali yordam beradi.',
      q4: 'Davolash usullaringiz qanday?',
      a4: 'Biz asosan tabiiy dorilar va xalq tabobati usullaridan (hijoma, zuluk, masaj) foydalanamiz.',
      q5: 'Bolalar uchun qanday masaj turlari bor?',
      a5: 'Gijja, immunitet pastligi va umumiy rivojlanish uchun sog\'lomlashtirish masajlari mavjud.',
      q6: 'Dorilaringiz xavfsizmi?',
      a6: 'Barcha dorilarimiz 100% tabiiy o\'simliklardan tayyorlangan va nojo\'ya ta\'siri yo\'q.',
    }
  },
  ru: {
    nav: {
      home: 'Главная',
      services: 'Услуги',
      gallery: 'Галерея',
      about: 'О нас',
      contact: 'Контакты',
      faq: 'Вопросы',
      theme_light: 'Дневной',
      theme_dark: 'Ночной',
    },
    carousel: {
      items: [
        { title: 'Качественный сервис', text: 'Мы обслуживаем на самом современном оборудовании.' },
        { title: 'Опытная табиба', text: 'У нас работает табиба с многолетним опытом.' },
        { title: 'Натуральные лекарства', text: 'Во всех наших процедурах используются 100% натуральные лекарства.' },
      ]
    },
    hero: {
      title: 'Шагаем вместе к здоровой жизни',
      subtitle: 'Мы предлагаем вам лучшие услуги в сочетании современной медицины и народной медицины.',
      cta: 'Наши услуги',
    },
    hero_tabs: [
      { title: 'Услуги', desc: 'Все наши медицинские услуги и процедуры', page: 'services' },
      { title: 'О нас', desc: 'История нашего центра и наши ценности', page: 'about' },
      { title: 'Вопросы', desc: 'Ответы на часто задаваемые вопросы', page: 'faq' },
      { title: 'Контакты', desc: 'Наш адрес и способы связи', page: 'contact' },
    ],
    services: {
      title: 'Наши услуги',
      list: [
        { title: "Общий осмотр", desc: "Полный осмотр тела с помощью аппарата TANITA." },
        { title: "Укрепление иммунитета", desc: "Стабилизация иммунитета натуральными лекарствами." },
        { title: "Лечение пиявками", desc: "Очистка крови и лечение с помощью пиявок." },
        { title: "Внутренние заболевания", desc: "Лечение заболеваний ЖКТ, анемии, дефицита витаминов и бесплодия." },
        { title: "Электрофорез", desc: "Использование современных методов физиотерапии." },
        { title: "Лечение парафином", desc: "Согревающие и лечебные парафиновые процедуры." },
        { title: "Хиджама", desc: "Кровопускание на основе народной медицины." },
        { title: "Массаж для женщин и детей", desc: "Профессиональный массаж от квалифицированной табибы." },
        { title: "Эффективное лечение глистов", desc: "Эффективное и натуральное лечение паразитов!" }
      ]
    },
    about_extra: {
      title: 'О нас',
      subtitle: 'Стремление к здоровой жизни - главная цель каждого человека. Наш центр предлагает вам самые качественные и натуральные процедуры на этом пути.',
      only_target: 'Услуги ТОЛЬКО для ЖЕНЩИН И ДЕТЕЙ!',
      features: [
        'Делаем хиджаму и массаж женщинам и детям',
        'Наша табиба: женщина',
        'Наши лекарства: 100% натуральные'
      ],
      view_map: 'ПОСМОТРЕТЬ НА КАРТЕ'
    },
    contact: {
      title: 'Свяжитесь с нами',
      address: 'Адрес',
      address_val: 'Ферганская область, Учкуприкский район, село Катта Куштеpa, махалля Обод, дом 5',
      phone: 'Телефон',
      email: 'Email',
      send: 'Отправить сообщение',
      form_name: 'Ваше имя',
      form_phone: 'Ваш телефон',
      form_email: 'Email',
      email_error: 'Введите корректный email (обязательно @)',
      name_error: 'Имя должно содержать только буквы',
      form_phone_optional: 'Ваш телефон (опционально)',
      form_email_optional: 'Email (опционально)',
      form_msg: 'Ваше сообщение',
      success: 'Сообщение успешно отправлено!',
      error: 'Ошибка при отправке сообщения.',
      requirement: 'Необходимо ввести хотя бы телефон или почту!',
    },
    faq: {
      title: 'Часто задаваемые вопросы',
      q1: 'Каков ваш график работы?',
      a1: 'Наш центр работает ежедневно с 08:00 до 16:00.',
      q2: 'Для кого услуги массажа?',
      a2: 'У нас есть профессиональные услуги массажа только для женщин и детей.',
      q3: 'В каких случаях полезна хиджама?',
      a3: 'Хиджама эффективно помогает улучшить кровообращение, при головных болях и общем недомогании.',
      q4: 'Каковы ваши методы лечения?',
      a4: 'В основном мы используем натуральные лекарства и методы народной медицины (хиджама, пиявки, массаж).',
      q5: 'Какие виды массажа есть для детей?',
      a5: 'Имеются оздоровительные массажи при паразитах, низком иммунитете и для общего развития.',
      q6: 'Безопасны ли ваши лекарства?',
      a6: 'Все наши лекарства изготовлены из 100% натуральных растений и не имеют побочных эффектов.',
    }
  },
  en: {
    nav: {
      home: 'Home',
      services: 'Services',
      gallery: 'Gallery',
      about: 'About Us',
      contact: 'Contact',
      faq: 'FAQ',
      theme_light: 'Light',
      theme_dark: 'Dark',
    },
    carousel: {
      items: [
        { title: 'Quality Service', text: 'We provide services with the most modern equipment.' },
        { title: 'Experienced Tabiba', text: 'We have a tabiba with many years of experience.' },
        { title: 'Natural Medicines', text: '100% natural medicines are used in all our treatments.' },
      ]
    },
    hero: {
      title: 'Walking together towards a healthy life',
      subtitle: 'We offer you the best services in a combination of modern medicine and folk medicine.',
      cta: 'Our Services',
    },
    hero_tabs: [
      { title: 'Services', desc: 'All our medical services and treatments', page: 'services' },
      { title: 'About Us', desc: 'Our center history and values', page: 'about' },
      { title: 'FAQ', desc: 'Answers to frequently asked questions', page: 'faq' },
      { title: 'Contact', desc: 'Our address and ways to get in touch', page: 'contact' },
    ],
    services: {
      title: 'Our Services',
      list: [
        { title: "General Checkup", desc: "Full body checkup using the TANITA device." },
        { title: "Immunity Boosting", desc: "Stabilizing immunity with natural medicines." },
        { title: "Leech Therapy", desc: "Blood purification and treatment using leeches." },
        { title: "Internal Diseases", desc: "Treatment of gastrointestinal diseases, anemia, vitamin deficiency, and infertility." },
        { title: "Electrophoresis", desc: "Using modern physiotherapy methods." },
        { title: "Paraffin Therapy", desc: "Warming and healing paraffin procedures." },
        { title: "Hijama", desc: "Bloodletting based on folk medicine." },
        { title: "Women and Children Massage", desc: "Professional massage by a qualified tabiba." },
        { title: "Effective Parasite Treatment", desc: "Effective and natural treatment for parasites!" }
      ]
    },
    about_extra: {
      title: 'About Us',
      subtitle: 'Striving for a healthy life is the main goal of every human being. Our center provides you with the highest quality and natural treatments on this path.',
      only_target: 'Services ONLY for WOMEN AND CHILDREN!',
      features: [
        'We do hijama and massage for women and children',
        'Our tabiba: female',
        'Our medicines: 100% natural'
      ],
      view_map: 'VIEW ON MAP'
    },
    contact: {
      title: 'Contact Us',
      address: 'Address',
      address_val: 'Fergana region, Uchkuprik district, Katta Kushtepa village, Obod mahalla, house 5',
      phone: 'Phone',
      email: 'Email',
      send: 'Send Message',
      form_name: 'Your Name',
      form_phone: 'Your Phone',
      form_email: 'Email',
      email_error: 'Enter a valid email (must contain @)',
      name_error: 'Name must contain only letters',
      form_phone_optional: 'Your Phone (optional)',
      form_email_optional: 'Your Email (optional)',
      form_msg: 'Your Message',
      success: 'Message sent successfully!',
      error: 'Error sending message.',
      requirement: 'At least phone or email is required!',
    },
    faq: {
      title: 'Frequently Asked Questions',
      q1: 'What are your working hours?',
      a1: 'Our center is open daily from 08:00 to 16:00.',
      q2: 'Who are the massage services for?',
      a2: 'We have professional massage services only for women and children.',
      q3: 'When is hijama useful?',
      a3: 'Hijama effectively helps to improve blood circulation, headache and general malaise.',
      q4: 'What are your treatment methods?',
      a4: 'We mainly use natural medicines and folk medicine methods (hijama, leeches, massage).',
      q5: 'What types of massage are there for children?',
      a5: 'There are wellness massages for parasites, low immunity and for general development.',
      q6: 'Are your medicines safe?',
      a6: 'All our medicines are made from 100% natural plants and have no side effects.',
    }
  }
};
