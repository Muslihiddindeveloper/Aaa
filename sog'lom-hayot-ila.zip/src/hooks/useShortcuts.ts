import { useEffect } from 'react';
import { Page } from '../types';

export function useShortcuts(setCurrentPage: (page: Page) => void) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Check for Ctrl + Shift combinations
      if (e.ctrlKey && e.shiftKey) {
        const key = e.key.toUpperCase();
        
        switch (key) {
          case 'I':
            e.preventDefault();
            setCurrentPage('about');
            break;
          case 'M':
            e.preventDefault();
            setCurrentPage('services');
            break;
          case 'J':
            e.preventDefault();
            setCurrentPage('contact');
            break;
        }
      }

      // Check for Ctrl + U
      if (e.ctrlKey && e.key.toLowerCase() === 'u') {
        e.preventDefault();
        setCurrentPage('faq');
      }

      // Disable other DevTools shortcuts (F12, etc.)
      if (e.key === 'F12') {
        e.preventDefault();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setCurrentPage]);
}
