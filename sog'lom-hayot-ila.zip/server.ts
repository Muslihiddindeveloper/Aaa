import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import fetch from 'node-fetch';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Telegram Proxy Route
  app.post('/api/contact', async (req, res) => {
    const { name, phone, email, message, ip, device } = req.body;
    const token = process.env.TELEGRAM_BOT_TOKEN || '8612596191:AAHpgAZGR6etKMAtcOLDw6cF27OjprD-4Yo';
    const chatId = process.env.TELEGRAM_CHAT_ID || '5302627260';

    const text = `
🆕 *Yangi Xabar!*
👤 *Ism:* ${name}
📞 *Tel:* ${phone || 'Noma\'lum'}
📧 *Email:* ${email || 'Noma\'lum'}
📝 *Xabar:* ${message}

🌐 *IP:* ${ip || 'Noma\'lum'}
📱 *Qurilma:* ${device || 'Noma\'lum'}
    `.trim();

    try {
      const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text: text,
          parse_mode: 'Markdown'
        })
      });

      if (response.ok) {
        res.json({ success: true });
      } else {
        const err = await response.text();
        console.error('Telegram API error:', err);
        res.status(500).json({ success: false, error: 'Telegram API error' });
      }
    } catch (error) {
      console.error('Fetch error:', error);
      res.status(500).json({ success: false, error: 'Internal server error' });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
